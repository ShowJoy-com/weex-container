package com.showjoy.weex;

public interface SHWeexConstants {

    String WEEX = "weex";

    String EXTRA_H5 = "h5";

    String EXTRA_TITLE = "title";
    String EXTRA_TITLE_BAR = "titleBar";
    String EXTRA_URL = "url";

    String NAME = "name";
    String DATA = "data";
}
