package com.showjoy.weex.event;

/**
 * Created by lufei on 3/30/17.
 */

public class WeexBaseEvent {

    public String instanceId;

    public WeexBaseEvent(String instanceId) {
        this.instanceId = instanceId;
    }
}
