package com.showjoy.weex.entities;

/**
 * Created by lufei on 11/15/16.
 */

public class WeexConfig {

    /**
     * page : order
     * url : https://dshdjshjbx.js
     * md5 : 323827382huwhdjshdjs
     * h5 : http://dsds.html
     * v : 1.0.0
     */

    public String page;
    public String url;
    public String md5;
    public String h5;
    public String v;
    public String hideTitleBar;
}
